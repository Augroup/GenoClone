def genotype(Record,Allele):
    gene=[]
    snps=Record.split('\t')
    for i in range(len(snps)-1):
        snp=snps[i].split(',')
        if len(snp)<7:
            gene.append(0)
            continue
        link=[]
        for j in range(len(snp)-1):
            somatic=snp[j][-1]
            germline=snp[j][-2]
            if somatic==Allele:
                link.append(germline)
        count=len(set(link))
        if count==1:
            gene.append(1)
        else:
            gene.append(2)

    return max(gene)
