function [f_C,f_val, W_C, Y_C, exit_flag]=Tumour_heterogeneity1(VAF,DP,C_max)
VAF=2*VAF;
exit_flag=1;
% Step 1
VAF1=unique(VAF);
T=length(VAF1);
% 
% if T==1
%    C=1;
%    W=1;
%    Y=ones(length(VAF),C);
% return 
% end
min_VAF=min(VAF);
if C_max>1/min_VAF
    C_max=floor(1/min_VAF);
end

f_C=zeros(length(DP),C_max);
f_val=zeros(C_max,1);
W_C=cell(C_max,1);
Y_C=cell(C_max,1);
%Variance
% Variance=zeros(length(DP),1);
% for i=1:length(DP)
%     Variance(i)=abs(binoinv(0.2,DP(i),VAF(i))/DP(i)-VAF(i));
% end
%Calculate the variance
% Var=sqrt(.25*.75/median(DP));
for C=1:C_max
    flag=1-C*min_VAF;
    if flag<0
        break
    end
    WW=zeros(C,1e4);
    YY=cell(1e4,1);
    ff=zeros(1e4,1);
    ff_all=cell(1e4,1);
    for i=1:1e4
        Y=zeros(length(VAF),C);
        weight=rand(C,1);
        W=weight/sum(weight)*(1-C*min_VAF)+min_VAF;
        [W,~]=sort(W);
        value=zeros(2^C-1,1);
        kk=0;
        flag=cell(2^C-1,1);
        combine_f=zeros(C,1);
        f_weight=zeros(length(DP),1);
        for j=1:C;
            AA=nchoosek(1:C,j);
            n=size(AA,1);
           
            for l=1:n
                 value(kk+l)=sum(W(AA(l,:)));
                 flag{kk+l}=AA(l,:);
            end
            kk=kk+n;
            combine_f(j)=kk;
        end
        for pp=1:T
            me_v=abs(value-VAF1(pp));
            flag1=find(me_v==min(me_v));
            if length(flag1)>1
                exit_flag=2;
                flag1=flag1(1);
            end
            flag2=flag{flag1};
            Y(VAF==VAF1(pp),flag2)=1;
            med_combine=find(combine_f>=flag1);
            f_weight(VAF==VAF1(pp))=med_combine(1);    
        end
        f=abs(VAF-Y*W).*f_weight./DP;
%         if sum(f<0.02)/length(f)>0.75
%            return;
%         end
        WW(:,i)=W;
        YY{i}=Y;
        ff(i)=sum(f);
        ff_all{i}=abs(VAF-Y*W);
    end
    flag_f=find(ff==min(ff));
    Y_C{C}=YY{flag_f(1)};
    W_C{C}=WW(:,flag_f(1));
    f_val(C)=ff(flag_f(1));
    f_C(:,C)=ff_all{flag_f(1)};
%    save(strcat(num2str(C),'_.mat'))
end  
