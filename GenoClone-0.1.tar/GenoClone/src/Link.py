#!/usr/bin/env python
#import os
from subprocess import PIPE, Popen
from ref_pos import ref_pos
from genotype import genotype
import sys
bam_path = sys.argv[3]
#os.environ['path']=path
fid=open(sys.argv[4],'wr+')
fid.write('SNV'+'\tFilter'+'\tDP4'+'\tDP'+'\tVAF'+'\tLink or not'+'\tDistance'+'\tGenotype'+'\tLink Info\n')
reads_length=100
z = 0
tot = 0
with open(sys.argv[2]) as inf:
  for line in inf:
    tot+=1
for line in open(sys.argv[2]):
    z+=1
    if line[0]=='#':
        continue 
    line1=line.split('\t')
    chr=line1[0]
    pos=int(line1[1])
    DP=sum([int(DP4) for DP4 in line1[11].split(',')])
    snv=chr+'_'+line1[1]+'_'+line1[3]+line1[4]+'\t'+line1[6]+'\t'+line1[11]+'\t'+str(DP)+'\t'+line1[12][:-1]
    start=pos-102400
    end=pos+102400
    #os.environ['start']=str(start)
    #os.environ['end']=str(end)
    #os.environ['chr']=chr
    #snps=os.popen("awk -v Chr=$chr -v n1=$start -v n2=$end '{if ($1 == Chr && $2 > n1 && $2 < n2) print}' "+sys.argv[1]).read()
    cmd = 'awk -v Chr='+chr+' -v n1='+str(start)+' -v n2='+str(end)+" '{if ($1 == Chr && $2 > n1 && $2 < n2) print}' "+sys.argv[1]
    #sys.stderr.write(cmd+"\n")
    p = Popen(cmd,stdout=PIPE,shell=True)
    snps = p.stdout.read()
    p.communicate()
    #snps=os.popen("awk -v Chr=$chr -v n1=$start -v n2=$end '{if ($1 == Chr && $2 > n1 && $2 < n2) print}' "+sys.argv[1]).read()

    if len(snps)==0:
        fid.write(snv+'\tnone\n')
        continue
    snv_pos=pos-reads_length
    bam_flag=chr+':'+str(start)+'-'+str(end)
    perc = int(100*float(z)/float(tot))
    sys.stderr.write(str(perc)+'% '+bam_flag+"            \r")
    #os.environ['flag']=flag
    #raw=os.popen("samtools view $path $flag|awk '/=/{print}'").read()


    cmd1 = 'samtools view '+bam_path+' '+bam_flag
    #sys.stderr.write(cmd1+"\n")
    cmd2 = "awk '/=/{print}'";
    #sys.stderr.write(cmd2+"\n")
    p1 = Popen(cmd1.split(),stdout=PIPE)
    p2 = Popen(cmd2,stdout=PIPE,stdin=p1.stdout,shell=True)
    raw = p2.stdout.read()
    p2.communicate()
    p1.communicate()

    #exact the mate-pair reads
    reads_raw=[element.split('\t') for element in raw.split('\n')]
    reads_need=[]
    for i in range(len(reads_raw)-1):
        reads_pos1=int(reads_raw[i][3])
        reads_pos2=int(reads_raw[i][7])
        if (reads_pos1<pos and snv_pos<reads_pos1) or (reads_pos2<pos and snv_pos<reads_pos2):
            reads_need.append(reads_raw[i])
    mate_reads=[]
    reads_need_name=[reads_need[i][0] for i in range(len(reads_need))]
    for i in range(len(reads_need)):
        reads_name=reads_need_name[i]
        if reads_need_name.count(reads_name)==2:
            mate_reads.append(reads_need[i])
    sorted_mate=sorted(mate_reads)
    snp=snps.split('\n')
    distance=[0]*(len(snp)-1)
    Record=''
    for i in range(len(snp)-1):
        snpi=snp[i].split('\t')
        snp_pos=int(snpi[1])
        distance[i]=abs(snp_pos-pos)
        j=0
        record=snpi[0]+'_'+snpi[1]+':'
        while j<len(sorted_mate):
            pos1=int(sorted_mate[j][3])
            pos2=int(sorted_mate[j][7])
            dis_snv1=pos-pos1
            dis_snv2=pos-pos2
            dis_snp1=snp_pos-pos1
            dis_snp2=snp_pos-pos2
            if sorted_mate[j][5].find('H')!=-1 or sorted_mate[j+1][5].find('H')!=-1:
                j=j+2
                continue
            dis_ref1=ref_pos(sorted_mate[j][5],len(sorted_mate[j][5]))
            dis_ref2=ref_pos(sorted_mate[j+1][5],len(sorted_mate[j+1][5]))
            if ((dis_snp1 not in dis_ref1) and (dis_snp2 not in dis_ref2)) or ((dis_snv1 not in dis_ref1) and (dis_snv2 not in dis_ref2)):
                j=j+2
                continue
            else:
                if dis_snv1 in dis_ref1:
                    snv_coden=sorted_mate[j][9][dis_ref1.index(dis_snv1)]
                else:
                    snv_coden=sorted_mate[j+1][9][dis_ref2.index(dis_snv2)]
                if dis_snp1 in dis_ref1:
                    snp_coden=sorted_mate[j][9][dis_ref1.index(dis_snp1)]
                else:
                    snp_coden=sorted_mate[j+1][9][dis_ref2.index(dis_snp2)]
                record=record+snp_coden+snv_coden+','
                j=j+2
        if record[-1]!=':':
            Record=Record + record+ '\t'
    if len(Record)==0:
        fid.write(snv+'\t'+'none\t'+str(min(distance))+'\n')
    else:
        gene_type=genotype(Record,line1[4])
        fid.write(snv+'\t'+'some\t'+str(min(distance))+'\t'+str(gene_type)+'\t'+Record+'\n')
sys.stderr.write("\n")
fid.close()
