%#!/usr/bin/env matlab
function GenoClone(input,output)
A=importdata(input,'\n');
data=cell(size(A,1),8);
for i=1:size(A,1)
    B=regexp(A{i},'\t','split');
    Size_B=length(B);
    if Size_B<8
        data(i,1:Size_B)=B;
    else
        data(i,:)=B(1:8);
    end
end
filter_flag=strcmp(data(:,2),'PASS');
link_flag=strcmp(data(:,6),'some');
genotype_flag=strcmp(data(:,8),'1');
% Get the homozygate site
Homo_flag=filter_flag & link_flag & genotype_flag;
VAF=str2double(data(Homo_flag,5));
DP=str2double(data(Homo_flag,4));
WW=zeros(2,1000);

flag_heter=(VAF<.5 & DP>10);
[f_C,f_val, W_C, Y_C, exit_flag]=Tumour_heterogeneity(VAF(flag_heter),DP(flag_heter),10);
goodness=sum(f_C<0.5/sqrt(median(DP(flag_heter))))/size(f_C,1);

%Plot the subclones
h1=subplot(1,2,1);
boxplot(f_C./2);
set(gca,'Position',[.1 .1 .3 .8])
title('Difference between true and observed VAF','FontSize',12)
ylabel('|VAF^{t}-VAF^{o}|','FontSize',10)
%subplot the goodness
h2=subplot(1,2,2);
set(gca,'Position',[.6 .1 .3 .8])
plot(1:size(f_C,2),goodness,'--gs','LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','b','MarkerFaceColor',[0.5,0.5,0.5]);
title('Goodness of # of sublones','FontSize',12)
ylabel('Goodness','FontSize',10)
set(gca,'xtick',1:size(f_C,2));
%xlim([0.7,2.3])
box off
%plot the common xlabelZZ
p1=get(h1,'position');
p2=get(h2,'position');
height=p1(2)+p1(4)-p2(2);
h3=axes('position',[.35 p2(2) p2(3) height],'visible','off');
xlabel(h3,'# of subclones','visible','on','FontSize',10);
%%
%%save the plot
h=suptitle(output);
set(h,'FontSize',20,'FontWeight','normal')
saveas(gcf,strcat(output,'.pdf'))
%% Calculate the subclones' number and output file to demonstrate
N_subclone=length(goodness);
for i=1:length(goodness)-1
    if goodness(i)>0.8 && abs(goodness(i+1)-goodness(i))<0.05
        N_subclone=i;
        break
    end
end
subclone_data=[goodness(1:N_subclone);W_C{N_subclone}';Y_C{N_subclone}];
rawname_M=data(Homo_flag,1);
subclone_name=['Goodness';'Subclone_fraction';rawname_M(flag_heter)];
Subclone1=[subclone_name num2cell(subclone_data)];
fid = fopen(strcat(output,'.csv'),'wt');
 if fid>0
     for k=1:size(Subclone1,1)
         fprintf(fid,strcat('%s,',repmat('%f,',1,N_subclone),'\n'),Subclone1{k,:});
     end
     fclose(fid);
 end

